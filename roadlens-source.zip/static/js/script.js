'use strict';
const $ = (id) => document.getElementById(id);
const state = { records: [], selected: null, previewUrl: null, model: null, stream: null, activeRecord: null, maps: {}, layers: {}, busy: false };
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const dateLabel = (value) => new Date(value).toLocaleString(undefined, {day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
let toastTimer;
function toast(message, error = false) { $('toast').textContent = message; $('toast').classList.toggle('error', error); $('toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').hidden = true, 6500); }
async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (response.status === 401) showLogin();
  if (!response.ok) throw new Error(data.error || 'The request could not be completed.');
  return data;
}
function showLogin() { if (!$('login-dialog').open) $('login-dialog').showModal(); }
function setView(name) {
  if (!$(`view-${name}`)) name = 'overview';
  document.querySelectorAll('.view').forEach(el => el.hidden = el.id !== `view-${name}`);
  document.querySelectorAll('.nav-link').forEach(el => el.classList.toggle('active', el.dataset.view === name));
  $('breadcrumb-title').textContent = ({overview:'Overview',inspect:'New inspection',map:'Damage map',history:'Inspection history',model:'Model & evaluation',project:'About the project'})[name];
  if (name === 'map') setTimeout(() => { ensureMap('full-map'); refreshMaps(); state.maps['full-map']?.invalidateSize(); }, 50);
  if (name === 'overview') setTimeout(() => state.maps['overview-map']?.invalidateSize(), 50);
  window.scrollTo({top:0,behavior:'instant'});
}
document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => location.hash = button.dataset.go));
window.addEventListener('hashchange', () => setView(location.hash.slice(1)));

function emptyState(title, description) { return `<div class="empty-state">${icon('list')}<h3>${escapeHTML(title)}</h3><p>${escapeHTML(description)}</p></div>`; }
function table(records, compact = false) {
  if (!records.length) return emptyState('No inspections to show', 'Create an inspection to start building your road-condition record.');
  return `<div class="table-wrap"><table><thead><tr><th>ROAD / LOCATION</th><th>DAMAGE CLASS</th><th>CONFIDENCE</th><th>STATUS</th>${compact?'':'<th>SEVERITY</th>'}<th>DATE</th><th></th></tr></thead><tbody>${records.map(r => `<tr><td><strong>${escapeHTML(r.location || 'Location not specified')}</strong><small>${escapeHTML(r.id.slice(0,8).toUpperCase())} ${r.latitude !== null ? '· Geotagged' : '· No coordinates'}</small></td><td>${escapeHTML(r.prediction)}</td><td>${r.confidence.toFixed(1)}%</td><td><span class="badge ${r.status==='Resolved'||r.status==='Verified'?'green':r.status==='Scheduled'?'blue':''}">${escapeHTML(r.status)}</span></td>${compact?'':`<td>${escapeHTML(r.severity)}</td>`}<td>${escapeHTML(dateLabel(r.created_at))}</td><td><button class="text-button" data-record="${r.id}" aria-label="Review inspection ${r.id.slice(0,8)}">Review ↗</button></td></tr>`).join('')}</tbody></table></div>`;
}
function renderRecords() {
  $('stat-total').textContent = state.records.length;
  $('stat-review').textContent = state.records.filter(r => r.status === 'Needs review').length;
  $('stat-located').textContent = state.records.filter(r => r.latitude !== null).length;
  $('stat-resolved').textContent = state.records.filter(r => r.status === 'Resolved').length;
  $('recent-table').innerHTML = table(state.records.slice(0,5), true);
  filterHistory(); refreshMaps();
}
function filterHistory() {
  const term = $('history-search').value.toLowerCase(), status = $('status-filter').value;
  const records = state.records.filter(r => (!status || r.status === status) && [r.id,r.location,r.prediction,r.notes].join(' ').toLowerCase().includes(term));
  $('history-table').innerHTML = table(records);
  $('history-count').textContent = `${records.length} record${records.length === 1 ? '' : 's'}`;
}
$('history-search').addEventListener('input', filterHistory);
$('status-filter').addEventListener('change', filterHistory);
document.addEventListener('click', event => { const button = event.target.closest('[data-record]'); if (button) openRecord(button.dataset.record); });

function ensureMap(id) {
  if (state.maps[id] || typeof L === 'undefined') return;
  if (!state.records.some(r => r.latitude !== null)) {
    $(id).innerHTML = '<div class="map-placeholder"><div><svg aria-hidden="true"><use href="#i-pin"/></svg><br>No geotagged inspections yet.<br><small>Add coordinates to an inspection to see coverage.</small></div></div>';
    return;
  }
  $(id).textContent = '';
  const map = L.map(id, {scrollWheelZoom:false, zoomControl:id==='full-map', attributionControl:true}).setView([28.47,77.49],11);
  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19, attribution:'© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>'}).addTo(map);
  tiles.once('tileerror', () => {
    map.removeLayer(tiles);
    const notice = document.createElement('div'); notice.className='map-offline-notice';
    notice.textContent='Basemap unavailable. Inspection markers and coordinates remain available.';
    $(id).append(notice);
  });
  state.maps[id] = map; state.layers[id] = L.layerGroup().addTo(map);
}
function refreshMaps() {
  const located = state.records.filter(r => r.latitude !== null && r.longitude !== null);
  ensureMap('overview-map');
  if (!$('view-map').hidden) ensureMap('full-map');
  $('map-count').textContent = `${located.length} geotagged`;
  $('full-map-count').textContent = `${located.length} located inspection${located.length===1?'':'s'}`;
  $('location-list').innerHTML = located.map(r => `<button class="location-item" data-record="${r.id}"><strong>${escapeHTML(r.location || r.prediction)}</strong><small>${r.latitude.toFixed(5)}, ${r.longitude.toFixed(5)} · ${escapeHTML(r.prediction)}</small></button>`).join('');
  for (const [id, map] of Object.entries(state.maps)) {
    state.layers[id].clearLayers();
    located.forEach(r => {
      const container = document.createElement('div');
      const title = document.createElement('strong'); title.textContent = r.location || 'Road inspection';
      const summary = document.createElement('div'); summary.textContent = `${r.prediction} · ${r.confidence.toFixed(1)}%`;
      const button = document.createElement('button'); button.textContent = 'Review inspection ↗'; button.addEventListener('click', () => openRecord(r.id));
      container.append(title,summary,button);
      L.marker([r.latitude,r.longitude], {icon:L.divIcon({className:'',html:'<div class="map-marker"></div>',iconSize:[16,16],iconAnchor:[8,8]})}).addTo(state.layers[id]).bindPopup(container);
    });
    if (located.length) map.fitBounds(located.map(r => [r.latitude,r.longitude]), {padding:[45,45],maxZoom:15});
  }
  if (typeof L === 'undefined') {
    $('overview-map').textContent = located.length ? `${located.length} locations. Map library is unavailable; coordinates remain in history.` : 'No geotagged inspections yet.';
    $('full-map').textContent = 'Map library is unavailable. View coordinates in the records below.';
  }
}
$('fit-map').addEventListener('click', () => { refreshMaps(); if (!state.records.some(r=>r.latitude!==null)) toast('Add coordinates to an inspection to place it on the map.'); });

function setImage(file) {
  if (state.busy) return;
  if (!file || !['image/jpeg','image/png','image/webp'].includes(file.type)) { toast('Choose a JPG, PNG, or WEBP image.',true); return; }
  if (file.size > 10*1024*1024) { toast('Image exceeds the 10 MB upload limit.',true); return; }
  if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
  state.selected = file; state.previewUrl = URL.createObjectURL(file);
  $('image-preview').src = state.previewUrl; $('image-preview').hidden = false; $('preview-badge').hidden = false; $('upload-empty').hidden = true;
  $('file-name').textContent = `${file.name} · ${(file.size/1024).toFixed(0)} KB`;
  $('analyze-button').disabled = !state.model?.ready;
  if (!state.model?.ready) toast('The trained model is not ready. See Model & evaluation.',true);
  $('analysis-result').innerHTML = initialResult;
}
const initialResult = $('analysis-result').innerHTML;
$('dropzone').addEventListener('click', () => { if (!state.busy) $('file-input').click(); });
$('dropzone').addEventListener('keydown', event => { if (['Enter',' '].includes(event.key)) { event.preventDefault(); if (!state.busy) $('file-input').click(); } });
$('file-input').addEventListener('change', event => setImage(event.target.files[0]));
['dragenter','dragover'].forEach(name => $('dropzone').addEventListener(name, event => { event.preventDefault(); $('dropzone').classList.add('dragging'); }));
['dragleave','drop'].forEach(name => $('dropzone').addEventListener(name, event => { event.preventDefault(); $('dropzone').classList.remove('dragging'); }));
$('dropzone').addEventListener('drop', event => setImage(event.dataTransfer.files[0]));
$('reset-button').addEventListener('click', () => {
  if (state.busy) return;
  if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
  state.selected = null; state.previewUrl = null; $('file-input').value = '';
  $('image-preview').hidden = true; $('image-preview').removeAttribute('src'); $('preview-badge').hidden = true; $('upload-empty').hidden = false;
  $('file-name').textContent = ''; $('analyze-button').disabled = true; $('analysis-result').innerHTML = initialResult;
  ['latitude','longitude','location'].forEach(id => $(id).value = '');
});
$('sample-button').addEventListener('click', async () => {
  try { const response = await fetch('/static/images/sample-road.jpg'); if (!response.ok) throw new Error('No sample image is installed. Upload a road image instead.');
    const blob = await response.blob(); setImage(new File([blob],'held-out-road.jpg',{type:'image/jpeg'}));
    toast('Held-out dataset image loaded. Run analysis for an actual prediction.');
  } catch (error) { toast(error.message,true); }
});
$('gps-button').addEventListener('click', () => {
  if (!navigator.geolocation) return toast('Location access is unavailable in this browser.',true);
  $('gps-button').disabled = true; $('gps-button').textContent = 'Locating…';
  navigator.geolocation.getCurrentPosition(position => {
    $('latitude').value = position.coords.latitude.toFixed(6); $('longitude').value = position.coords.longitude.toFixed(6);
    $('gps-button').disabled = false; $('gps-button').textContent = 'Use my location';
    toast(`Device location added (accuracy ±${Math.round(position.coords.accuracy)} m). Confirm this is where the image was captured.`);
  }, error => { $('gps-button').disabled = false; $('gps-button').textContent = 'Use my location'; toast(error.code === 1 ? 'Location permission was denied. Enter coordinates manually.' : 'Could not get your location. Enter coordinates manually.',true); }, {enableHighAccuracy:true,timeout:12000,maximumAge:0});
});
function probabilityChart(probabilities) {
  return Object.entries(probabilities).sort((a,b)=>b[1]-a[1]).map(([name,value]) => `<div class="probability"><div class="probability-label"><span>${escapeHTML(name)}</span><span>${value.toFixed(1)}%</span></div><div class="probability-bar"><span style="width:${Math.max(0,Math.min(100,value))}%"></span></div></div>`).join('');
}
$('analyze-button').addEventListener('click', async () => {
  if (!state.selected || state.busy) return;
  const lat = $('latitude').value, lon = $('longitude').value;
  if ((lat && !lon) || (!lat && lon) || (lat && (!Number.isFinite(Number(lat)) || Math.abs(Number(lat))>90 || !Number.isFinite(Number(lon)) || Math.abs(Number(lon))>180))) return toast('Enter valid latitude and longitude together, or leave both blank.',true);
  state.busy = true; $('analyze-button').disabled = true;
  $('analysis-result').innerHTML = '<div class="loading"><span class="spinner"></span>Analyzing the road image…<p class="muted">Running the trained PyTorch CNN</p></div>';
  const body = new FormData(); body.append('image',state.selected); body.append('location',$('location').value); body.append('latitude',lat); body.append('longitude',lon);
  try {
    const result = await api('/predict',{method:'POST',body});
    $('analysis-result').innerHTML = `<div class="result-main"><div class="result-class"><small>DOMINANT DAMAGE CLASS</small><h3>${escapeHTML(result.prediction)}</h3><div class="confidence-row"><strong>${result.confidence.toFixed(1)}%</strong><span>model confidence</span></div></div><h4>Class probabilities</h4>${probabilityChart(result.probabilities)}<div class="review-notice">${result.review_required?'Low-confidence prediction. Inspector verification is required.':'Inspection saved. Review the image and assign severity before taking action.'}</div><button class="button secondary" data-record="${result.record.id}">Review inspection ${icon('arrow')}</button><div class="result-meta">${escapeHTML(result.record.id.slice(0,8).toUpperCase())} · ${result.record.inference_ms.toFixed(0)} ms model inference<br>Whole-image classification. No defect localization or automated severity.</div></div>`;
    await refreshData(); toast('Analysis complete. Inspection saved.');
  } catch(error) { $('analysis-result').innerHTML = `<div class="error-box"><strong>Analysis could not be completed</strong>${escapeHTML(error.message)}</div>`; }
  finally { state.busy = false; $('analyze-button').disabled = !state.selected || !state.model?.ready; }
});

$('camera-button').addEventListener('click', async () => {
  if (!navigator.mediaDevices?.getUserMedia) return toast('Camera access needs HTTPS or localhost and a supported browser.',true);
  try { state.stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false}); $('camera-video').srcObject = state.stream; $('camera-dialog').showModal(); }
  catch(error) { toast('Camera unavailable or permission denied. You can upload an image instead.',true); }
});
function stopCamera() { state.stream?.getTracks().forEach(track => track.stop()); state.stream = null; $('camera-video').srcObject = null; }
$('close-camera').addEventListener('click', () => $('camera-dialog').close());
$('camera-dialog').addEventListener('close', stopCamera);
$('capture-button').addEventListener('click', () => {
  const video = $('camera-video'); if (!video.videoWidth) return toast('Wait for the camera to become ready.',true);
  const canvas = document.createElement('canvas'); canvas.width=video.videoWidth; canvas.height=video.videoHeight; canvas.getContext('2d').drawImage(video,0,0);
  canvas.toBlob(blob => { setImage(new File([blob],`road-capture-${Date.now()}.jpg`,{type:'image/jpeg'})); $('camera-dialog').close(); },'image/jpeg',.9);
});
window.addEventListener('pagehide',stopCamera);

async function openRecord(id) {
  try {
    const {record:r} = await api(`/api/inspections/${id}`); state.activeRecord = r;
    $('record-title').textContent = r.location || r.prediction;
    $('record-content').innerHTML = `<div class="record-layout"><div><img class="record-image" src="${r.image_url}" alt="Inspection road image"><p class="print-note">Original evidence · Image-level classification</p></div><div class="record-info"><strong>${escapeHTML(r.prediction)}</strong><br>${r.confidence.toFixed(1)}% model confidence<br>${escapeHTML(dateLabel(r.created_at))}<br>Record ${escapeHTML(r.id.slice(0,8).toUpperCase())}<br>${r.latitude===null?'No coordinates recorded':`${r.latitude.toFixed(6)}, ${r.longitude.toFixed(6)}`}<br><strong>Severity: ${escapeHTML(r.severity)}</strong><br>Status: ${escapeHTML(r.status)}<p>Notes: ${escapeHTML(r.notes || 'No review notes yet.')}</p><small>Model ${escapeHTML(r.model_sha256.slice(0,12))} · ${r.inference_ms.toFixed(0)} ms</small></div></div><div class="record-review"><h3>Inspector assessment</h3><p class="muted">Severity is assigned by a person, independent of model confidence.</p><div class="field-pair"><div><label for="review-status">Status</label><select id="review-status">${['Needs review','Verified','Scheduled','Resolved'].map(s=>`<option ${s===r.status?'selected':''}>${s}</option>`).join('')}</select></div><div><label for="review-severity">Severity</label><select id="review-severity">${['Unassessed','Low','Moderate','High'].map(s=>`<option ${s===r.severity?'selected':''}>${s}</option>`).join('')}</select></div></div><label for="review-notes">Review notes</label><textarea id="review-notes" rows="3" maxlength="2000" placeholder="Condition observed, recommended action, or maintenance reference…">${escapeHTML(r.notes)}</textarea></div><div class="record-actions"><button class="button primary" id="save-review">Save review</button><button class="button secondary" id="print-record">Print report / PDF</button><button class="text-button danger-button" id="delete-record">Delete record</button></div><p class="print-note">AI supports screening. Final maintenance decisions require human assessment. Confidence does not measure severity.</p>`;
    if (!$('record-dialog').open) $('record-dialog').showModal();
    $('save-review').addEventListener('click',async()=>{
      try { await api(`/api/inspections/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:$('review-status').value,severity:$('review-severity').value,notes:$('review-notes').value})}); await refreshData(); await openRecord(id); toast('Inspector assessment saved.'); }
      catch(error){toast(error.message,true);}
    });
    $('print-record').addEventListener('click',()=>window.print());
    $('delete-record').addEventListener('click',async()=>{
      if(!window.confirm('Delete this inspection and its stored image? This cannot be undone.'))return;
      try { await api(`/api/inspections/${id}`,{method:'DELETE'}); $('record-dialog').close(); await refreshData(); toast('Inspection and image deleted.'); }
      catch(error){toast(error.message,true);}
    });
  } catch(error){toast(error.message,true);}
}
$('close-record').addEventListener('click',()=>$('record-dialog').close());
function renderModel() {
  const m=state.model;
  $('model-status').innerHTML=`<span class="dot"></span>${m.ready?'Model ready · ResNet18':'Model unavailable'}`;
  $('model-status').classList.toggle('unavailable',!m.ready);
  $('analyze-button').disabled=!m.ready||!state.selected;
  if(!m.ready){$('model-details').innerHTML=`<div class="error-box"><strong>Training required</strong>${escapeHTML(m.error)}<p>Prepare real images with prepare_dataset.py, then run train.py and evaluate.py. Restart the server after installing the checkpoint.</p></div>`;return;}
  const metrics=m.metrics, sizes=m.metadata.split_sizes||{};
  $('model-details').innerHTML=`${metrics?`<div class="model-grid">${[['Test accuracy',metrics.accuracy],['Macro precision',metrics.precision_macro],['Macro recall',metrics.recall_macro],['Macro F1',metrics.f1_macro]].map(([label,value])=>`<article class="card model-card"><span>${label}</span><strong>${(value*100).toFixed(1)}%</strong></article>`).join('')}</div>`:'<div class="error-box">No evaluation matching the installed checkpoint is available. Run evaluate.py.</div>'}<article class="card model-summary"><h2>ResNet18 transfer-learning classifier</h2><p>${escapeHTML(m.metadata.classes.join(' · '))}<br>Training: ${sizes.train??'—'} images · Validation: ${sizes.val??'—'} · Test: ${sizes.test??'—'}<br>Selected checkpoint: epoch ${m.metadata.epoch} · Input: ${m.metadata.image_size} × ${m.metadata.image_size} RGB<br>Checkpoint fingerprint: ${escapeHTML(m.model_sha256.slice(0,16))}</p><div class="pipeline"><span>RGB image</span><b>→</b><span>Resize & normalize</span><b>→</b><span>ResNet18 CNN</span><b>→</b><span>Softmax</span></div>${metrics?'<p>Metrics are measured on the held-out test split. This is an academic baseline, not a field-validated road assessment system.</p><details><summary>View measured evaluation charts</summary><img class="model-chart" src="/api/evaluation/confusion_matrix.png" alt="Actual held-out test confusion matrix"><img class="model-chart" src="/api/evaluation/training_accuracy.png" alt="Measured training and validation accuracy"><img class="model-chart" src="/api/evaluation/training_loss.png" alt="Measured training and validation loss"></details>':''}</article>`;
}
async function refreshData(){ const data=await api('/api/inspections');state.records=data.records;renderRecords(); }
async function initialize(){
  setView(location.hash.slice(1)||'overview');
  try {
    const auth=await api('/auth/status');
    if(auth.required&&!auth.authenticated){showLogin();return;}
    state.model=await api('/api/model');renderModel();
    ensureMap('overview-map');await refreshData();
  }catch(error){toast(error.message,true);$('model-status').innerHTML='<span class="dot"></span>Connection unavailable';}
}
$('login-dialog').addEventListener('cancel',event=>event.preventDefault());
$('login-form').addEventListener('submit',async event=>{
  event.preventDefault();
  try{await api('/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});$('password').value='';$('login-error').textContent='';$('login-dialog').close();await initialize();}
  catch(error){$('login-error').textContent=error.message;}
});
$('account-button').addEventListener('click',async()=>{
  const auth=await api('/auth/status');
  if(!auth.required)return toast('Local workspace. Set APP_PASSWORD before sharing access.');
  if(window.confirm('Sign out of this workspace?')){await api('/auth/logout',{method:'POST'});state.records=[];renderRecords();showLogin();}
});
initialize();
