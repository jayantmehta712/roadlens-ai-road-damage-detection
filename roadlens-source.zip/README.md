# RoadLens — AI Road Damage Detection and Classification

A runnable B.Tech project combining a real PyTorch ResNet18 CNN with a Flask inspection workspace. Upload or capture a road image, classify its dominant damage, optionally attach coordinates, and keep a searchable maintenance record. The interface adapts the geotagging, dashboard, map, history, and reporting workflow from the supplied entrepreneurship pitch.

This is an **academic pilot**, not a field-validated or safety-certified road assessment service. See `models/MODEL_CARD.md` and `results/BASELINE.md` for the actual training run, measured results, and dataset limitations. No hard-coded predictions, fabricated accuracy, or artificial bounding boxes are used.

## Quick start on Windows

Install **Python 3.12, 64-bit** from [python.org](https://www.python.org/downloads/). Run these commands from this project directory in PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). No activation-policy changes are necessary. The supplied bundle includes the trained best checkpoint, selected real dataset split, and measured evaluation files. If starting from a source-only Git checkout, restore or train the checkpoint first.

On the computer where this project was built, `Start-RoadLens.cmd` also recognizes the already prepared sibling `work/venv` environment. After extracting the ZIP elsewhere, follow the installation commands above; subsequent launches can use `Start-RoadLens.cmd`.

On Linux/macOS:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

The requirements select matching CPU PyTorch/torchvision builds, suitable for a CPU web server. For CUDA training, use the matching installation command from [PyTorch](https://pytorch.org/get-started/previous-versions/) in a separate training environment. The application uses Waitress locally and Gunicorn on Render. No TensorFlow, Keras, YOLOv8, or other YOLO dependency is used.

## Features

- Responsive dashboard with counts computed from stored inspections.
- Image upload, drag and drop, preview, camera capture, reset, and loading/error states.
- Four genuine RDD damage classes: D00 longitudinal crack, D10 transverse crack, D20 alligator crack, D40 pothole.
- Actual class probabilities and model inference time.
- Optional device GPS or manual coordinates and road label.
- Leaflet/OpenStreetMap location view, with coordinate records available if basemap tiles fail.
- SQLite inspection history, search, status filtering, inspector-assigned severity and notes.
- CSV export and per-inspection print report; choose “Save as PDF” in the browser print dialog.
- Model page with measured test metrics, confusion matrix, and learning curves.
- Private-workspace password authentication for online deployment.

## How it works

```text
Image / camera frame
  → validate and decode with Pillow
  → EXIF orientation and RGB conversion with Pillow
  → resize and ImageNet normalization
  → ResNet18 CNN (convolutions, ReLU, residual blocks, pooling)
  → linear classification head and softmax
  → damage class and probabilities
  → OpenCV evidence encoding + SQLite record + optional coordinates
  → dashboard / map / inspector review / report
```

`model.py` returns logits for numerically stable `CrossEntropyLoss`. `predict.py` applies softmax and returns probabilities. The model is loaded once when the application starts, runs on CPU in evaluation mode, and uses `torch.no_grad()`. A lock and concurrency limit bound simultaneous inference.

### Alignment with the supplied references

| Reference idea | Implementation |
| --- | --- |
| Image analysis, confidence | PyTorch ResNet18 transfer-learning classifier |
| OpenCV image processing | RGB/BGR conversion, evidence downscaling and metadata-free JPEG encoding; shared torchvision transforms for CNN input |
| Geotagging, date and time | Optional device/manual coordinates, UTC timestamps displayed in browser local time |
| Central dashboard and map | Flask-served dashboard, Leaflet, OpenStreetMap |
| Detection history and reports | SQLite, CSV export, browser-print reports |
| Severity and prioritization | Human-assigned severity and review status; never derived from confidence |
| Synopsis proposes YOLO/FastAPI/React/MongoDB | This version follows the pasted Flask/CNN/HTML brief; object detection and those alternative services are not implemented |
| Pitch suggests Normal and Severe Damage | Not invented as ML classes. Only classes backed by the selected annotations are trained |

### Important limits for a viva

This is **image classification**, not object detection. It predicts one dominant damage type for the whole image, even if several defects are visible. It does not draw defect boxes or calculate mAP. RDD annotation boxes are used only to derive training labels, never copied onto inference images. There is no trained “healthy road” class, so an arbitrary clean-road or non-road image may still receive one of the damage labels. Class probabilities are not calibrated correctness estimates or severity measurements. All maintenance decisions need human review.

## Project files

```text
app.py                 Flask API, authentication, validation and routes
config.py              environment-based paths and training defaults
model.py               dynamically sized ResNet18 classification head
data.py                shared transforms, ImageFolder loading, duplicate checks
prepare_dataset.py     real RDD VOC annotations → classification split
train.py               Adam / weighted cross entropy, best + final checkpoints
evaluate.py            untouched test split, metrics and confusion matrix
predict.py             checkpoint loading and CPU inference
storage.py             parameterized SQLite persistence
templates/index.html   application shell and accessible form controls
static/                local CSS/JS, Leaflet, sample road image
dataset/               selected train/val/test images + provenance manifest
models/                trained best checkpoint and model card
results/               real metrics, learning curves, confusion matrix
tests/                 API, validation, authentication and real-model tests
render.yaml            Render service + persistent disk blueprint
gunicorn.conf.py       production server configuration
```

## Dataset and attribution

The source is [RDD2022, official Figshare release](https://figshare.com/articles/dataset/RDD2022_-_The_multi-national_Road_Damage_Dataset_released_through_CRDDC_2022/21431547), by Arya et al. See the [authors’ repository](https://github.com/sekilab/RoadDamageDetector) and [dataset paper](https://arxiv.org/abs/2209.08538). The Figshare release metadata specifies **CC BY 4.0**. Dataset attribution is recorded in `DATASET_ATTRIBUTION.md`; preserve it when sharing the selected images. The full original archive is approximately 13.3 GB and is not needed to run the supplied bundle.

The included subset is composed of real images with a single supported annotated damage class. A “single annotated class” does not guarantee that every visible defect was annotated. Neighboring filename blocks of 100 frames stay in one split. Exact byte duplicates across splits are rejected. This reduces some leakage, but filename groups are not verified GPS-disjoint locations, and country/class bias remains. Do not present baseline test scores as real-world reliability.

### Prepare a larger dataset

Download and extract RDD2022 from the official source. Put extracted country directories under a source directory, retaining `images` and `annotations/xmls` (or an equivalent recursive structure). Then:

```powershell
.\.venv\Scripts\python.exe prepare_dataset.py --source C:\datasets\RDD2022 --output C:\datasets\road-split --max-per-class 1000 --single-class
$env:DATASET_DIR='C:\datasets\road-split'
```

`prepare_dataset.py` refuses to replace an existing populated output. It discovers image names and actual labels from XML; only the documented RDD codes are converted. For another dataset, create `train/<class>`, `val/<class>`, `test/<class>` manually. The training code discovers all folder classes dynamically and writes `classes.json`; it requires matching nonempty class folders in each split. Add a properly annotated normal-road class only if you have suitable genuine examples.

### Train

The included dataset can be used directly:

```powershell
.\.venv\Scripts\python.exe train.py --epochs 10 --batch-size 16 --freeze-backbone
.\.venv\Scripts\python.exe evaluate.py
```

The first transfer-learning run downloads genuine ImageNet ResNet18 weights from the official PyTorch host. `--freeze-backbone` trains the new linear head while preserving pretrained features. Omit it to fine-tune the complete CNN (slower, GPU recommended). Use `--from-scratch` to train without ImageNet weights. Hyperparameters can be passed by CLI or `EPOCHS`, `BATCH_SIZE`, `LEARNING_RATE`, `IMAGE_SIZE` environment variables. The training command writes:

- `models/road_damage_model.pth`: checkpoint with the best validation accuracy.
- `models/final_model.pth`: final epoch checkpoint.
- `classes.json`, `results/training_history.json`, and actual learning-curve PNGs.

Run `evaluate.py` once after choosing the model with validation data; do not tune on test results. It writes `results/metrics.json` with accuracy, macro precision/recall/F1 and per-class scores, plus `results/confusion_matrix.png`. Checkpoint hashing prevents the UI from displaying evaluation from a different model. Restart the server after changing the model. Class order and image size are loaded from the checkpoint, not hard-coded at inference.

## API

| Endpoint | Behavior |
| --- | --- |
| `GET /` | Web interface |
| `GET /health` | Process liveness and `model_ready` |
| `POST /predict` | Multipart `image`, optional `location`, `latitude`, `longitude`; stores inspection |
| `GET /api/model` | Checkpoint metadata and matching measured metrics |
| `GET /api/inspections` | Latest 2,000 records |
| `GET/PATCH/DELETE /api/inspections/<id>` | Read, review or delete a record and its image |
| `GET /api/export.csv` | Spreadsheet-safe CSV export |
| `GET /media/<id>` | Validated, re-encoded evidence image |
| `GET /auth/status`, `POST /auth/login`, `POST /auth/logout` | Workspace session authentication |

Example call (local mode without a password):

```powershell
curl.exe -F "image=@C:\photos\road.jpg" -F "location=Campus entrance" http://127.0.0.1:5000/predict
```

A successful prediction returns HTTP **201** and JSON with `success`, `prediction`, `class_code`, `confidence` (0–100), `probabilities` (0–100, approximately summing to 100), `review_required`, `analysis_type`, `record`, and `result_image`. Invalid images return 400; oversized requests 413; absent model 503; busy inference 429. `/health` is a liveness endpoint, so inspect `model_ready` for inference readiness.

## Tests

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
```

Tests exercise health/home, extension and content validation, corrupt images, coordinate range and NaN checks, upload limits, missing-model handling, session protection, cross-origin rejection, actual checkpoint inference, confidence normalization, storage/review, CSV formula escaping, image serving, deletion, and security headers. Synthetic solid-color test input checks the API contract only; no claim is made about its semantic prediction. Tests do not inject inference results into the running app. Browser checks cover layout and the sample → analyze → review/history flow. Physical camera/GPS permissions need a real device and are not simulated as successful.

## GitHub and Render deployment

Online hosting requires your GitHub and Render accounts. No public deployment is claimed by this local bundle. Follow [Render’s Flask guide](https://render.com/docs/deploy-flask) and the steps below. This project uses a persistent disk, which requires a paid disk-capable Render service; review Render’s current pricing before provisioning. The blueprint selects `starter`, but no purchase or service creation has been made for you.

1. Create an empty GitHub repository. From the project directory:

   ```powershell
   git init
   git add .
   git add -f models/road_damage_model.pth results/metrics.json results/training_history.json results/confusion_matrix.png results/training_accuracy.png results/training_loss.png
   git commit -m "Add RoadLens inspection application and trained baseline"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/roadlens.git
   git push -u origin main
   ```

   Datasets, raw uploads, local databases, secrets and the final duplicate checkpoint stay out of Git. The best checkpoint is approximately 45 MB; if your hosting workflow uses model storage instead, restore the exact checkpoint before the build readiness check. Never load an untrusted PyTorch checkpoint.

2. In Render choose **New → Blueprint**, connect that repository, and select the included `render.yaml`. Review its service/disk cost. Set a strong `APP_PASSWORD`; Render generates `SECRET_KEY`. The build command installs requirements and validates the model. The start command is `gunicorn -c gunicorn.conf.py app:app`, which binds Render’s `PORT` on `0.0.0.0`.
3. The disk mounts `/var/data`; `DATA_DIR=/var/data/roadlens` keeps uploads and SQLite records across deployments. Without persistent storage, records disappear when an ephemeral instance is replaced.
4. Open the returned HTTPS URL, sign in, upload a real road image, and verify the result, history, map coordinates and CSV export. Check `/health` has `model_ready: true`.

For a manually created service use Python 3.12, `pip install -r requirements.txt && python scripts/check_model.py`, and `gunicorn -c gunicorn.conf.py app:app`. Set `APP_ENV=production`, `APP_PASSWORD`, `SECRET_KEY`, and persistent `DATA_DIR`. Production startup fails without its password and signing secret. The proxy configuration trusts Render’s forwarded HTTPS scheme; run production only behind your trusted HTTPS proxy.

## Security and operational scope

Uploads are restricted by extension, decoded format, file size (10 MB) and image pixels (20 million). Filenames use server-generated IDs; stored images are re-encoded to JPEG and EXIF metadata is removed. User text is escaped in the UI, SQL is parameterized, exports escape spreadsheet formulas, API/media routes honor session authentication, cross-origin mutation requests are rejected, and errors do not expose server paths or stack traces. Sessions use HttpOnly/SameSite cookies and Secure cookies under production HTTPS.

This pilot has one shared workspace password, one app worker, a local SQLite database, simple login throttling, and a 2,000-record history view limit. Before serving a multi-organization public product, add individual accounts/roles, managed database/object storage, retention policy, monitoring, tested backups and restore, and an independent security review. Back up the database and uploads together while writes are paused. Stored images can contain people/vehicles; obtain appropriate consent and retain only what is needed. Deletion removes a record and image permanently. Print reports reflect the saved review; save edits before printing.

Map tiles require network access and compliance with the [OpenStreetMap tile policy](https://operations.osmfoundation.org/policies/tiles/). Camera and GPS need browser permission and localhost/HTTPS. Model confidence is not a guarantee; use this tool for supervised screening.

## Project team

Jayant Mehta (18309), Kavya (17257), Kashish Vohra (18315), and Ayush Sharma (18282). Guide: Professor Manisha. Dronacharya Group of Institutions, Greater Noida; B.Tech CSIT, academic session 2026–27.
