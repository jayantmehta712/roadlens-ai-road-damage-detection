"""Fail a deployment build that would otherwise have no usable model."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from predict import Predictor
predictor=Predictor()
if predictor.model is None: raise SystemExit(predictor.error)
print('Trained checkpoint is loadable:', predictor.metadata['classes'])
