"""Flask application. Image-level CNN output is never presented as bounding boxes."""
import csv
import hashlib
import hmac
import io
import json
import logging
import math
import os
import secrets
import time
import uuid
import warnings
from datetime import datetime, timezone, timedelta
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError
import torch
from flask import Flask, jsonify, render_template, request, send_file, session
from werkzeug.exceptions import HTTPException
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
import config
from predict import Predictor, ModelUnavailable
from storage import Store
from image_processing import save_evidence

torch.set_num_threads(min(4, torch.get_num_threads()))
Image.MAX_IMAGE_PIXELS = 20_000_000
EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}
FORMATS = {'JPEG', 'PNG', 'WEBP'}
STATUSES = {'Needs review', 'Verified', 'Scheduled', 'Resolved'}
SEVERITIES = {'Unassessed', 'Low', 'Moderate', 'High'}


def create_app(test_config=None, predictor=None):
    app = Flask(__name__)
    production = os.getenv('APP_ENV') == 'production'
    if production and (not os.getenv('SECRET_KEY') or not os.getenv('APP_PASSWORD')):
        raise RuntimeError('Production requires SECRET_KEY and APP_PASSWORD.')
    app.config.update(SECRET_KEY=os.getenv('SECRET_KEY') or secrets.token_hex(32),
        MAX_CONTENT_LENGTH=10 * 1024 * 1024, MAX_FORM_MEMORY_SIZE=64 * 1024,
        DATA_DIR=os.getenv('DATA_DIR', str(config.ROOT / 'instance')),
        APP_PASSWORD=os.getenv('APP_PASSWORD', ''), SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Strict', SESSION_COOKIE_SECURE=production,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
    if test_config: app.config.update(test_config)
    if production:
        # Render terminates HTTPS at its trusted reverse proxy.
        app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_for=0, x_host=0, x_port=0)
    data_dir = Path(app.config['DATA_DIR'])
    uploads = data_dir / 'uploads'; uploads.mkdir(parents=True, exist_ok=True)
    store = Store(data_dir / 'inspections.sqlite3')
    engine = predictor if predictor is not None else Predictor()
    model_hash = hashlib.sha256(config.MODEL_PATH.read_bytes()).hexdigest() if config.MODEL_PATH.exists() else 'unavailable'
    app.extensions.update(store=store, predictor=engine)
    # Bound concurrent inference to avoid exhausting a small CPU instance.
    import threading
    inference_slot = threading.BoundedSemaphore(2)
    login_attempts = {}

    @app.before_request
    def access_control():
        if request.method in {'POST', 'PATCH', 'DELETE'}:
            origin = request.headers.get('Origin')
            if origin and origin != request.host_url.rstrip('/'):
                return jsonify(success=False, error='Cross-origin requests are not allowed.'), 403
        protected = request.path.startswith(('/api/', '/media/')) or request.path == '/predict'
        if protected and app.config['APP_PASSWORD'] and not session.get('authenticated'):
            return jsonify(success=False, error='Please sign in to access inspections.'), 401

    @app.after_request
    def security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Permissions-Policy'] = 'camera=(self), geolocation=(self), microphone=()'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; script-src 'self' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com; "
            "img-src 'self' data: blob: https://tile.openstreetmap.org https://unpkg.com; "
            "media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        if not request.path.startswith('/static/'):
            response.headers['Cache-Control'] = 'no-store'
        if production: response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        return response

    @app.get('/')
    def index():
        return render_template('index.html')

    @app.get('/health')
    def health():
        return jsonify(status='healthy', model_ready=engine.model is not None)

    @app.get('/auth/status')
    def auth_status():
        return jsonify(required=bool(app.config['APP_PASSWORD']),
                       authenticated=bool(session.get('authenticated')))

    @app.post('/auth/login')
    def login():
        address = request.remote_addr or 'local'
        now = time.monotonic()
        attempts = [stamp for stamp in login_attempts.get(address, []) if now - stamp < 300]
        if len(attempts) >= 10:
            return jsonify(success=False, error='Too many attempts. Try again in five minutes.'), 429
        password = (request.get_json(silent=True) or {}).get('password', '')
        if not isinstance(password, str) or not hmac.compare_digest(password.encode(), app.config['APP_PASSWORD'].encode()):
            login_attempts[address] = attempts + [now]
            return jsonify(success=False, error='Incorrect password.'), 401
        session.clear(); session['authenticated'] = True; session.permanent = True
        login_attempts.pop(address, None)
        return jsonify(success=True)

    @app.post('/auth/logout')
    def logout():
        session.clear()
        return jsonify(success=True)

    @app.get('/api/model')
    def model_info():
        metrics_path = config.RESULTS / 'metrics.json'
        metrics = json.loads(metrics_path.read_text()) if metrics_path.exists() else None
        if metrics and metrics.get('checkpoint_sha256') != model_hash:
            metrics = None
        return jsonify(ready=engine.model is not None, error=engine.error,
            architecture='ResNet18 CNN', metadata=engine.metadata, metrics=metrics,
            model_sha256=model_hash, classification_only=True)

    @app.get('/api/evaluation/<filename>')
    def evaluation_plot(filename):
        if filename not in {'confusion_matrix.png', 'training_accuracy.png', 'training_loss.png'}:
            return jsonify(success=False, error='Evaluation plot not found.'), 404
        metrics_path = config.RESULTS / 'metrics.json'
        plot = config.RESULTS / filename
        if not metrics_path.exists() or not plot.exists() or json.loads(metrics_path.read_text()).get('checkpoint_sha256') != model_hash:
            return jsonify(success=False, error='Evaluate the installed checkpoint first.'), 404
        return send_file(plot, mimetype='image/png')

    def coordinates():
        lat, lon = request.form.get('latitude', '').strip(), request.form.get('longitude', '').strip()
        if not lat and not lon: return None, None
        if not lat or not lon: raise ValueError('Provide both latitude and longitude.')
        lat, lon = float(lat), float(lon)
        if not math.isfinite(lat) or not math.isfinite(lon) or not -90 <= lat <= 90 or not -180 <= lon <= 180:
            raise ValueError('Coordinates must be valid latitude and longitude values.')
        return lat, lon

    @app.post('/predict')
    def predict():
        uploaded = request.files.get('image')
        if uploaded is None or not uploaded.filename:
            return jsonify(success=False, error='Choose a road image first.'), 400
        safe_name = secure_filename(uploaded.filename)
        if '.' not in safe_name or safe_name.rsplit('.', 1)[-1].lower() not in EXTENSIONS:
            return jsonify(success=False, error='Use a JPG, PNG, or WEBP image.'), 400
        try:
            lat, lon = coordinates()
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                image = Image.open(uploaded.stream)
                if image.format not in FORMATS:
                    raise ValueError('The file contents are not a supported image.')
                image.load()
                image = ImageOps.exif_transpose(image).convert('RGB')
                if min(image.size) < 32:
                    raise ValueError('Use an image at least 32 pixels wide and high.')
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
            return jsonify(success=False, error=str(exc) if isinstance(exc, ValueError) else 'The image is invalid, corrupted, or too large.'), 400
        if not inference_slot.acquire(blocking=False):
            return jsonify(success=False, error='The analyzer is busy. Please retry shortly.'), 429
        started = time.perf_counter()
        try:
            result = engine.predict(image)
        except ModelUnavailable as exc:
            return jsonify(success=False, error=str(exc)), 503
        finally:
            inference_slot.release()
        inference_ms = (time.perf_counter() - started) * 1000
        identifier = uuid.uuid4().hex
        filename = identifier + '.jpg'
        # Re-encode strips EXIF/GPS metadata and never serves executable upload bytes.
        save_evidence(image, uploads / filename)
        record = dict(id=identifier, created_at=datetime.now(timezone.utc).isoformat(), filename=filename,
            prediction=result['prediction'], class_code=result['class_code'], confidence=result['confidence'],
            probabilities=result['probabilities'], latitude=lat, longitude=lon,
            location=request.form.get('location', '').strip()[:160], severity='Unassessed',
            status='Needs review', notes='', review_required=result['review_required'],
            model_sha256=model_hash, inference_ms=inference_ms)
        try:
            store.add(record)
        except Exception:
            (uploads / filename).unlink(missing_ok=True)
            raise
        return jsonify(success=True, **result, record=store.get(identifier),
                       result_image='/media/' + identifier), 201

    @app.get('/api/inspections')
    def inspections():
        return jsonify(records=store.list())

    @app.route('/api/inspections/<identifier>', methods=['GET', 'PATCH', 'DELETE'])
    def inspection(identifier):
        record = store.get(identifier)
        if not record: return jsonify(success=False, error='Inspection not found.'), 404
        if request.method == 'DELETE':
            store.delete(identifier)
            (uploads / record['filename']).unlink(missing_ok=True)
            return jsonify(success=True)
        if request.method == 'PATCH':
            data = request.get_json(silent=True) or {}
            status, severity = data.get('status', record['status']), data.get('severity', record['severity'])
            notes = data.get('notes', record['notes'])
            if status not in STATUSES or severity not in SEVERITIES or not isinstance(notes, str) or len(notes) > 2000:
                return jsonify(success=False, error='Invalid review fields.'), 400
            store.update(identifier, status, severity, notes)
        return jsonify(record=store.get(identifier))

    @app.get('/media/<identifier>')
    def media(identifier):
        record = store.get(identifier)
        if not record or not (uploads / record['filename']).is_file():
            return jsonify(success=False, error='Image not found.'), 404
        return send_file(uploads / record['filename'], mimetype='image/jpeg')

    @app.get('/api/export.csv')
    def export_csv():
        output = io.StringIO(newline='')
        fields = ['id', 'created_at', 'prediction', 'confidence', 'latitude', 'longitude', 'location',
                  'severity', 'status', 'notes', 'model_sha256', 'inference_ms']
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction='ignore'); writer.writeheader()
        for record in store.list():
            # Prevent spreadsheet-formula execution when opening exported free text.
            record = {k: ("'" + v if isinstance(v, str) and v.startswith(('=', '+', '-', '@', '\t', '\r')) else v)
                      for k, v in record.items()}
            writer.writerow(record)
        return send_file(io.BytesIO(output.getvalue().encode('utf-8-sig')), mimetype='text/csv',
                         as_attachment=True, download_name='road-inspections.csv')

    @app.errorhandler(413)
    def too_large(error):
        return jsonify(success=False, error='Image exceeds the 10 MB upload limit.'), 413

    @app.errorhandler(Exception)
    def error_handler(error):
        if isinstance(error, HTTPException):
            return jsonify(success=False, error=error.description), error.code
        app.logger.exception('Request failed')
        return jsonify(success=False, error='The request could not be completed. Please try again.'), 500

    return app


app = create_app()

if __name__ == '__main__':
    from waitress import serve
    print('RoadLens running at http://127.0.0.1:5000', flush=True)
    serve(app, host=os.getenv('HOST', '127.0.0.1'), port=int(os.getenv('PORT', '5000')), threads=4)
