# RoadLens baseline model card

Trained and evaluated on 20 October 2026 for a final-year academic prototype.

## Model and objective

PyTorch / torchvision ResNet18 with genuine ImageNet-pretrained features and a newly trained four-output linear head. The backbone and batch-normalization statistics were frozen. This is **whole-image classification**: D00 longitudinal crack, D10 transverse crack, D20 alligator crack, D40 pothole. It does not localize damage, measure dimensions or severity, recognize normal roads, or compute object-detection mAP.

## Real training run

- RDD2022 source images from India and Japan; official release and license in DATASET_ATTRIBUTION.md.
- 560 training images (140 per class), 120 validation images (30 per class), 119 held-out test images (29 D00, 30 each other class).
- Only images with one supported annotated class were selected. Source label and original SHA-256 for each image are in dataset/manifest.json.
- Fixed seed 42. Country plus 100-frame filename groups stay in one split. Byte-identical cross-split images are rejected.
- RGB input resized to 224 × 224; ImageNet mean/std normalization. Training uses horizontal flips, rotations up to 7 degrees, and mild brightness/contrast jitter.
- Adam; learning rate 0.001; batch size 16; weighted CrossEntropyLoss; 10 epochs on CPU. No test data was used to fit weights or select the checkpoint.
- Selected checkpoint: epoch 10; validation accuracy 0.6667.
- Training duration recorded in the checkpoint: 229.4 seconds (excludes initial pretrained-weight download).
- Checkpoint SHA-256: `6efedcc0c9757ca733eb94106e1f82fd2dd931fd9a9ad39eb9a3dae8e3d6e589`.

## Measured held-out test performance

| Metric | Value |
| --- | --- |
| Accuracy | 0.6387 |
| Macro precision | 0.6255 |
| Macro recall | 0.6359 |
| Macro F1 | 0.6186 |

Per-class precision/recall/F1/support and the exact test-image count are in results/metrics.json. The confusion matrix and learning curves are generated from the actual run. This checkpoint was evaluated after training; it was not retrained in response to its test score.

## Material limits

This intentionally small subset is **strongly confounded by country and class**: D10 has 193 Japan images and 7 India images, whereas D00, D20 and D40 are from India. The model may learn differences in scenes, capture conditions or road texture rather than damage alone. Scores are therefore a demonstration baseline, not an unbiased estimate of road-damage recognition in new locations. A stronger study must balance classes across countries and evaluate on separate, independently collected locations.

Filename blocks are a proxy for neighboring frames, not verified route/GPS groups. Exact-byte deduplication does not find all visually similar frames. There is no healthy/non-road rejection class, no probability calibration, and no independently annotated severity label. Several defects may appear even when only one class is annotated. The whole-image label is not a claim that every visible defect was annotated.

CPU inference is supported; this run did not measure long-term service load, field reliability or safety outcomes. Confidence below 70% triggers a review hint; that threshold is a UI screening rule, not a validated operating point. Severity remains unassessed until a person sets it.

## Intended use

Student demonstration, supervised exploration, and reproducible pipeline development. Do not use this baseline to make autonomous safety or maintenance-dispatch decisions. No regulatory or field-production readiness is claimed.

## Reproduction

Use the included exact dataset split, install requirements.txt, run `python train.py --epochs 10 --batch-size 16 --freeze-backbone`, then `python evaluate.py`. The real source images, classes, manifest, best/final checkpoints, history and charts are included in the downloadable bundle. Bitwise training reproducibility across platforms is not guaranteed. Dataset and model artifacts are ignored in Git by default; README.md describes explicitly adding the deployment checkpoint and results.
