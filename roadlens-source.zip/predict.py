import threading
from pathlib import Path
from PIL import Image, ImageOps
import torch
import config
from data import preprocessing
from model import build_model


class ModelUnavailable(RuntimeError):
    pass


class Predictor:
    def __init__(self, path=config.MODEL_PATH):
        self.path = Path(path)
        self.model = None
        self.lock = threading.Lock()
        self.metadata = {}
        self.error = None
        if self.path.exists():
            try:
                checkpoint = torch.load(self.path, map_location='cpu', weights_only=True)
                self.classes = checkpoint['classes']
                if not self.classes or len(set(self.classes)) != len(self.classes):
                    raise ValueError('Invalid class metadata')
                self.model = build_model(len(self.classes))
                self.model.load_state_dict(checkpoint['state_dict'])
                self.model.eval()
                self.transform = preprocessing(checkpoint['image_size'])
                self.metadata = {k: v for k, v in checkpoint.items() if k != 'state_dict'}
            except Exception:
                self.model = None
                self.error = 'The checkpoint could not be loaded. Retrain or verify the model file.'
        else:
            self.error = 'No trained model is installed. Prepare the dataset and run train.py.'

    def predict(self, image):
        if self.model is None:
            raise ModelUnavailable(self.error)
        image = ImageOps.exif_transpose(image).convert('RGB')
        tensor = self.transform(image).unsqueeze(0)
        with self.lock, torch.no_grad():
            probabilities = torch.softmax(self.model(tensor), dim=1)[0].tolist()
        index = max(range(len(probabilities)), key=probabilities.__getitem__)
        code = self.classes[index]
        return {'prediction': config.CLASS_NAMES.get(code, code.replace('_', ' ').title()),
            'class_code': code, 'confidence': probabilities[index] * 100,
            'probabilities': {config.CLASS_NAMES.get(c, c.replace('_', ' ').title()): p * 100
                              for c, p in zip(self.classes, probabilities)},
            'review_required': probabilities[index] < 0.70,
            'analysis_type': 'dominant_image_classification'}


_predictor = None


def predict_image(image_path):
    global _predictor
    if _predictor is None:
        _predictor = Predictor()
    with Image.open(image_path) as image:
        return _predictor.predict(image)
