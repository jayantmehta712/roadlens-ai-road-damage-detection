import io
from PIL import Image
import pytest
from app import create_app
from predict import Predictor


@pytest.fixture
def client(tmp_path):
    app=create_app({'TESTING':True,'DATA_DIR':str(tmp_path),'APP_PASSWORD':''})
    return app.test_client()


def image_bytes():
    data=io.BytesIO(); Image.new('RGB',(64,64),(110,110,110)).save(data,format='PNG');data.seek(0);return data


def test_home_and_health(client):
    assert client.get('/').status_code==200
    assert b'roadlens' in client.get('/').data
    assert client.get('/health').json['status']=='healthy'


def test_bad_uploads(client):
    assert client.post('/predict').status_code==400
    assert client.post('/predict',data={'image':(io.BytesIO(b'x'),'x.exe')}).status_code==400
    assert client.post('/predict',data={'image':(io.BytesIO(b'not an image'),'x.jpg')}).status_code==400
    assert client.post('/predict',data={'image':(image_bytes(),'x.png'),'latitude':'nan','longitude':'1'}).status_code==400
    assert client.post('/predict',data={'image':(image_bytes(),'x.png'),'latitude':'91','longitude':'1'}).status_code==400
    assert client.post('/predict',data={'image':(io.BytesIO(b'x'*11*1024*1024),'x.jpg')}).status_code==413


def test_missing_model(tmp_path):
    engine=Predictor(tmp_path/'missing.pth')
    client=create_app({'TESTING':True,'DATA_DIR':str(tmp_path)},predictor=engine).test_client()
    response=client.post('/predict',data={'image':(image_bytes(),'x.png')})
    assert response.status_code==503
    assert 'No trained model' in response.json['error']


def test_authentication_and_origin(tmp_path):
    app=create_app({'TESTING':True,'DATA_DIR':str(tmp_path),'APP_PASSWORD':'test-only-password'})
    client=app.test_client()
    assert client.get('/api/inspections').status_code==401
    assert client.post('/auth/login',json={'password':'wrong'}).status_code==401
    assert client.post('/auth/login',json={'password':'test-only-password'},headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/auth/login',json={'password':'test-only-password'}).status_code==200
    assert client.get('/api/inspections').status_code==200
    client.post('/auth/logout')
    assert client.get('/api/inspections').status_code==401


def test_real_checkpoint_and_inspection_lifecycle(client):
    # This test requires the actual trained model; it never injects test predictions.
    assert client.get('/health').json['model_ready'], 'Install/train the checkpoint before this integration test.'
    result=client.post('/predict',data={'image':(image_bytes(),'../../road.png'),
        'location':'=HYPERLINK("x")','latitude':'28.47','longitude':'77.49'})
    assert result.status_code==201
    data=result.json
    assert data['success'] and 0<=data['confidence']<=100
    assert abs(sum(data['probabilities'].values())-100)<.001
    assert data['analysis_type']=='dominant_image_classification'
    record=data['record'];identifier=record['id']
    assert record['severity']=='Unassessed'
    assert client.get(record['image_url']).content_type=='image/jpeg'
    assert client.get('/api/inspections').json['records'][0]['id']==identifier
    assert client.patch('/api/inspections/'+identifier,json={'status':'bogus'}).status_code==400
    assert client.patch('/api/inspections/'+identifier,json={'severity':'High','status':'Verified','notes':'Reviewed on site'}).json['record']['severity']=='High'
    csv=client.get('/api/export.csv')
    assert csv.status_code==200 and b"'=HYPERLINK" in csv.data
    assert client.delete('/api/inspections/'+identifier).status_code==200
    assert client.get(record['image_url']).status_code==404
    assert not client.get('/api/inspections').json['records']


def test_safety_headers_and_error_paths(client):
    response=client.get('/')
    assert response.headers['X-Content-Type-Options']=='nosniff'
    assert "frame-ancestors 'none'" in response.headers['Content-Security-Policy']
    assert client.get('/media/../../config.py').status_code==404
    assert client.get('/api/inspections/missing').status_code==404
