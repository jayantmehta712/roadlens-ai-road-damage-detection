$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$candidates = @(
    (Join-Path $PSScriptRoot '.venv\Scripts\python.exe'),
    (Join-Path $PSScriptRoot '..\..\work\venv\Scripts\python.exe')
)
foreach ($candidate in $candidates) {
    if (Test-Path -LiteralPath $candidate) {
        & $candidate app.py
        exit $LASTEXITCODE
    }
}
Write-Host 'Create .venv and install requirements first; see README.md.'
exit 1
