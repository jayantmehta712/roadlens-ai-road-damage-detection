"""Small, explicit configuration shared by training and the web application."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATASET = Path(os.getenv('DATASET_DIR', ROOT / 'dataset'))
MODEL_PATH = Path(os.getenv('MODEL_PATH', ROOT / 'models/road_damage_model.pth'))
RESULTS = ROOT / 'results'
IMAGE_SIZE = int(os.getenv('IMAGE_SIZE', '224'))
BATCH_SIZE = int(os.getenv('BATCH_SIZE', '16'))
EPOCHS = int(os.getenv('EPOCHS', '12'))
LEARNING_RATE = float(os.getenv('LEARNING_RATE', '0.001'))
SEED = 42
CLASS_NAMES = {'D00': 'Longitudinal crack', 'D10': 'Transverse crack',
               'D20': 'Alligator crack', 'D40': 'Pothole'}
