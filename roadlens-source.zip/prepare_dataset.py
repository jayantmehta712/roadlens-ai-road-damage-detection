"""Convert real RDD Pascal VOC annotations to an image-classification dataset.

One label per image: the annotation class with the largest total labeled area.
Use --single-class to exclude images annotated with multiple damage classes.
Adjacent filename groups stay in one split; exact duplicate bytes are removed.
"""
import argparse
import hashlib
import json
import random
import re
import shutil
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path
import config


def prepare(source, target, max_per_class=400, single_class=False):
    source, target = Path(source), Path(target)
    if target.exists() and any((target / s).exists() and any((target/s).rglob('*.jpg')) for s in ['train','val','test']):
        raise ValueError('Output already contains images. Choose a new --output to preserve the existing split.')
    images = {path.name: path for path in source.rglob('*') if path.suffix.lower() in {'.jpg','.jpeg','.png'}}
    candidates, seen, skipped = [], set(), Counter()
    for annotation in sorted(source.rglob('*.xml')):
        try:
            root = ET.parse(annotation).getroot()
            image = images.get(root.findtext('filename', '')) or images.get(annotation.stem + '.jpg')
            if image is None: skipped['missing_image'] += 1; continue
            areas = defaultdict(float)
            for item in root.findall('object'):
                code = (item.findtext('name') or '').strip()
                if code not in config.CLASS_NAMES: continue
                box = item.find('bndbox')
                if box is None: continue
                x1,y1,x2,y2 = [float(box.findtext(key,'0')) for key in ['xmin','ymin','xmax','ymax']]
                areas[code] += max(0,x2-x1)*max(0,y2-y1)
            if not areas: skipped['no_supported_damage'] += 1; continue
            if single_class and len(areas) != 1: skipped['multiple_classes'] += 1; continue
            digest = hashlib.sha256(image.read_bytes()).hexdigest()
            if digest in seen: skipped['duplicate_bytes'] += 1; continue
            seen.add(digest)
            # Image sequences from the same country and 100-frame block cannot
            # cross splits. This reduces adjacent-frame leakage, but isn't a
            # substitute for a location-disjoint field evaluation.
            match = re.match(r'(.+?)(\d+)$', image.stem)
            group = f'{match[1]}{int(match[2])//100:05d}' if match else image.stem
            candidates.append(dict(image=image, code=max(areas,key=areas.get), group=group,
                                   sha256=digest, annotation=annotation.name,
                                   annotation_source=str(annotation.relative_to(source))))
        except (ET.ParseError, OSError, ValueError):
            skipped['invalid_annotation'] += 1
    if not candidates: raise ValueError('No annotated road images found. Pass the extracted RDD country directory.')
    groups = sorted({r['group'] for r in candidates}); random.Random(config.SEED).shuffle(groups)
    train_end, val_end = int(len(groups)*.7), int(len(groups)*.85)
    mapping = {g: 'train' if i<train_end else 'val' if i<val_end else 'test' for i,g in enumerate(groups)}
    caps = {'train':int(max_per_class*.7),'val':int(max_per_class*.15),'test':int(max_per_class*.15)}
    random.Random(config.SEED).shuffle(candidates)
    counts, manifest = Counter(), []
    (target/'annotations').mkdir(parents=True,exist_ok=True)
    for split in caps:
        for code in config.CLASS_NAMES: (target/split/code).mkdir(parents=True,exist_ok=True)
    for row in candidates:
        split=mapping[row['group']]; code=row['code']
        if counts[split,code] >= caps[split]: continue
        dest=target/split/code/row['image'].name
        shutil.copy2(row['image'],dest)
        shutil.copy2(source/row['annotation_source'],target/'annotations'/row['annotation'])
        counts[split,code]+=1
        manifest.append({k:(str(v.relative_to(source)) if k=='image' else v) for k,v in row.items()} | {'split':split})
    missing=[f'{s}/{c}' for s in caps for c in config.CLASS_NAMES if not counts[s,c]]
    if missing: raise ValueError('Some classes have no images in a split: '+', '.join(missing)+'. Use a larger source or revise grouping. Partial output preserved.')
    summary={'source':'RDD2022 / official Figshare release',
             'countries':sorted({r['image'].stem.split('_')[0] for r in candidates}),
             'seed':config.SEED,'label_policy':'single annotated class' if single_class else 'largest total annotated bounding-box area',
             'split_policy':'country and 100-frame filename blocks; disjoint source groups; byte deduplication',
             'counts':{s:{c:counts[s,c] for c in config.CLASS_NAMES} for s in caps},'skipped':dict(skipped),
             'limitation':'Filename grouping reduces adjacent-frame leakage but does not verify geographic independence.'}
    (target/'manifest.json').write_text(json.dumps(manifest,indent=2))
    (target/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,help='Extracted RDD directory containing images and VOC XML annotations')
    parser.add_argument('--output',default=str(config.DATASET))
    parser.add_argument('--max-per-class',type=int,default=400)
    parser.add_argument('--single-class',action='store_true')
    args=parser.parse_args()
    if args.max_per_class < 20: parser.error('--max-per-class must be at least 20')
    prepare(args.source,args.output,args.max_per_class,args.single_class)
