"""Train on real ImageFolder images; never invent data or evaluation numbers."""
import argparse
import json
import random
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import config
from data import load_split, check_leakage
from model import build_model


def run_epoch(model, loader, criterion, optimizer, device):
    training = optimizer is not None
    model.train(training)
    # Keep pretrained batch-normalization statistics stable when freezing features.
    if training and not next(model.conv1.parameters()).requires_grad:
        for module in model.modules():
            if isinstance(module, nn.BatchNorm2d):
                module.eval()
    total_loss = correct = total = 0
    with torch.set_grad_enabled(training):
        for images, targets in loader:
            images, targets = images.to(device), targets.to(device)
            if training:
                optimizer.zero_grad()
            logits = model(images)
            loss = criterion(logits, targets)
            if training:
                loss.backward()
                optimizer.step()
            total_loss += loss.item() * len(targets)
            correct += (logits.argmax(1) == targets).sum().item()
            total += len(targets)
    return total_loss / total, correct / total


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=str, default=str(config.DATASET))
    parser.add_argument('--epochs', type=int, default=config.EPOCHS)
    parser.add_argument('--batch-size', type=int, default=config.BATCH_SIZE)
    parser.add_argument('--lr', type=float, default=config.LEARNING_RATE)
    parser.add_argument('--image-size', type=int, default=config.IMAGE_SIZE)
    parser.add_argument('--freeze-backbone', action='store_true')
    parser.add_argument('--from-scratch', action='store_true')
    args = parser.parse_args()
    if args.epochs < 1:
        parser.error('--epochs must be positive')
    torch.manual_seed(config.SEED); np.random.seed(config.SEED); random.seed(config.SEED)
    torch.set_num_threads(min(4, torch.get_num_threads()))
    train = load_split(args.data, 'train', args.image_size)
    val = load_split(args.data, 'val', args.image_size, train.classes)
    test = load_split(args.data, 'test', args.image_size, train.classes)
    check_leakage(('train', train), ('val', val), ('test', test))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = build_model(len(train.classes), not args.from_scratch, args.freeze_backbone).to(device)
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
    counts = np.bincount(train.targets, minlength=len(train.classes))
    weights = torch.tensor(len(train) / (len(counts) * counts), dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(weight=weights)
    loaders = [DataLoader(ds, batch_size=args.batch_size, shuffle=i == 0, num_workers=0)
               for i, ds in enumerate((train, val))]
    config.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    config.RESULTS.mkdir(parents=True, exist_ok=True)
    history, best = [], -1
    started = time.time()
    metadata = {'architecture': 'resnet18', 'classes': train.classes, 'image_size': args.image_size,
        'seed': config.SEED, 'split_sizes': {'train': len(train), 'val': len(val), 'test': len(test)},
        'freeze_backbone': args.freeze_backbone, 'pretrained': not args.from_scratch}
    for epoch in range(args.epochs):
        train_loss, train_acc = run_epoch(model, loaders[0], criterion, optimizer, device)
        val_loss, val_acc = run_epoch(model, loaders[1], criterion, None, device)
        row = dict(epoch=epoch + 1, train_loss=train_loss, val_loss=val_loss,
                   train_accuracy=train_acc, val_accuracy=val_acc)
        history.append(row)
        print(f'Epoch {epoch + 1}/{args.epochs} train loss={train_loss:.4f} acc={train_acc:.3f}; '
              f'val loss={val_loss:.4f} acc={val_acc:.3f}', flush=True)
        checkpoint = dict(metadata, state_dict=model.state_dict(), epoch=epoch + 1,
                          validation_accuracy=val_acc, training_seconds=time.time() - started)
        if val_acc > best:
            best = val_acc
            torch.save(checkpoint, config.MODEL_PATH)
    torch.save(checkpoint, config.MODEL_PATH.with_name('final_model.pth'))
    (config.ROOT / 'classes.json').write_text(json.dumps(train.classes, indent=2))
    (config.RESULTS / 'training_history.json').write_text(json.dumps(history, indent=2))
    for metric in ['accuracy', 'loss']:
        fig, ax = plt.subplots()
        for split in ['train', 'val']:
            ax.plot([r['epoch'] for r in history], [r[f'{split}_{metric}'] for r in history], label=split)
        ax.set(xlabel='Epoch', ylabel=metric.title(), title=f'Training and validation {metric}')
        ax.legend(); fig.tight_layout(); fig.savefig(config.RESULTS / f'training_{metric}.png'); plt.close(fig)
    print(f'Best validation accuracy: {best:.4f}. Run evaluate.py on the untouched test split.')


if __name__ == '__main__':
    main()
