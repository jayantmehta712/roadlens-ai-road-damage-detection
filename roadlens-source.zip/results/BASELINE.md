# Measured baseline results

This file describes the real run bundled with RoadLens. It is not an expected or fabricated result.

- Training: 560 real RDD2022 images; validation: 120; test: 119.
- ResNet18 pretrained backbone frozen; new classification head trained for 10 epochs.
- Selected epoch: 10; validation accuracy: 66.67%.
- Held-out test accuracy: **63.87%** (76/119 correct).
- Macro precision: 62.55%; macro recall: 63.59%; macro F1: 61.86%.

The test score was not used to retune the model. Inspect metrics.json for per-class scores, training_history.json for all epochs, confusion_matrix.png for test errors, and training_accuracy.png / training_loss.png for the learning curves. The checkpoint hash in metrics.json binds the evaluation to the shipped model.

Country and class are strongly correlated in this small India/Japan subset. Filename-block separation and byte deduplication do not establish geographic independence or eliminate near duplicates. The test score must not be presented as field reliability. models/MODEL_CARD.md explains the limitations and how to reproduce the run.

## Verification performed

Six automated API tests passed, including an actual-checkpoint prediction and inspection storage/review/export/delete lifecycle. Browser checks cover the responsive layout and genuine sample-image analysis. Physical camera/GPS permissions are not claimed as tested. Public Render deployment remains pending account access and the target service.
