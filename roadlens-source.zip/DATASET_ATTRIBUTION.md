# RDD2022 subset attribution

Source: **RDD2022 — The multi-national Road Damage Dataset released through CRDDC 2022**, Arya et al.

- Official release: https://doi.org/10.6084/m9.figshare.21431547
- Authors' repository: https://github.com/sekilab/RoadDamageDetector
- Dataset paper: https://arxiv.org/abs/2209.08538
- Release archive file ID: `38030910`.
- License stated in official Figshare API metadata at retrieval: **Creative Commons Attribution 4.0 International** (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/.

Selected images and source XML labels were downloaded from the unmodified India and Japan country archives. Original image names and image bytes are retained in the classification dataset. Only images with a single supported annotation class were selected. Images are reorganized into training/validation/test directories; source boxes are converted to one classification label per image. The application displays resized/re-encoded evidence when an image is analyzed. A held-out image is also copied into `static/images/sample-road.jpg`; its source is identified in `dataset/sample_source.json`.

Preserve this attribution and the relevant source license when sharing these images or derivatives. Dataset images are not original RoadLens artwork. `dataset/manifest.json` records each selected source image, annotation filename, original SHA-256, group, class and split. `dataset/annotations/` includes the corresponding original VOC XML files for label auditing. `dataset/summary.json` records counts and split policy.

Dataset labels do not establish physical severity or whether every visible defect was annotated. No normal-road label is inferred from an absent damage annotation.
