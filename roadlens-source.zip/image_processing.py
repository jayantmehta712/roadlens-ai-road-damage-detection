"""OpenCV image processing for safe, metadata-free evidence storage."""
from pathlib import Path
import cv2
import numpy as np


def save_evidence(image, destination, max_side=1920):
    # Pillow has already decoded and corrected EXIF orientation. OpenCV receives
    # RGB pixels, converts to BGR, resizes and encodes fresh JPEG bytes.
    pixels = cv2.cvtColor(np.asarray(image.convert('RGB')), cv2.COLOR_RGB2BGR)
    height, width = pixels.shape[:2]
    if max(height, width) > max_side:
        scale = max_side / max(height, width)
        pixels = cv2.resize(pixels, (round(width * scale), round(height * scale)), interpolation=cv2.INTER_AREA)
    success, encoded = cv2.imencode('.jpg', pixels, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if not success:
        raise RuntimeError('Evidence image could not be encoded.')
    Path(destination).write_bytes(encoded.tobytes())
