"""SQLite is deliberately small and portable for a single-institution pilot."""
import json
import sqlite3
from pathlib import Path


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS inspections (
                id TEXT PRIMARY KEY, created_at TEXT NOT NULL, filename TEXT NOT NULL,
                prediction TEXT NOT NULL, class_code TEXT NOT NULL, confidence REAL NOT NULL,
                probabilities TEXT NOT NULL, latitude REAL, longitude REAL,
                location TEXT NOT NULL, severity TEXT NOT NULL, status TEXT NOT NULL,
                notes TEXT NOT NULL, review_required INTEGER NOT NULL,
                model_sha256 TEXT NOT NULL, inference_ms REAL NOT NULL)''')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        return db

    def add(self, record):
        data = dict(record)
        data['probabilities'] = json.dumps(data['probabilities'])
        keys = list(data)
        with self.connect() as db:
            db.execute(f'INSERT INTO inspections ({",".join(keys)}) VALUES ({",".join("?" for _ in keys)})',
                       [data[k] for k in keys])

    @staticmethod
    def unpack(row):
        if row is None: return None
        data = dict(row)
        data['probabilities'] = json.loads(data['probabilities'])
        data['review_required'] = bool(data['review_required'])
        data['image_url'] = '/media/' + data['id']
        return data

    def list(self):
        with self.connect() as db:
            return [self.unpack(row) for row in db.execute('SELECT * FROM inspections ORDER BY created_at DESC LIMIT 2000')]

    def get(self, identifier):
        with self.connect() as db:
            return self.unpack(db.execute('SELECT * FROM inspections WHERE id=?', (identifier,)).fetchone())

    def update(self, identifier, status, severity, notes):
        with self.connect() as db:
            db.execute('UPDATE inspections SET status=?, severity=?, notes=? WHERE id=?',
                       (status, severity, notes, identifier))

    def delete(self, identifier):
        with self.connect() as db:
            db.execute('DELETE FROM inspections WHERE id=?', (identifier,))
