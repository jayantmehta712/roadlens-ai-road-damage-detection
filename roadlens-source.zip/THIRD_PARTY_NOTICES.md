# Third-party resources

- **RDD2022 images and annotations**: Arya et al.; source and CC BY 4.0 attribution in `DATASET_ATTRIBUTION.md`.
- **Leaflet 1.9.4**: Vladimir Agafonkin and contributors. BSD 2-Clause license included in `static/vendor/LEAFLET-LICENSE.txt`.
- **OpenStreetMap tiles**: © OpenStreetMap contributors. Attribution is displayed in maps. Tile usage policy: https://operations.osmfoundation.org/policies/tiles/ . Basemap availability depends on the provider and network.
- **ResNet18 pretrained backbone**: downloaded from the official PyTorch model distribution via torchvision. Uses ImageNet-pretrained weights and a new classification head trained on the declared RDD subset. Torchvision is BSD licensed; dataset/model usage conditions remain applicable. No road-damage prediction head was borrowed or represented as newly trained without training.
- **RoadLens logo and abstract road illustration**: original SVG/CSS assets created for this project. No external image-generation service was used.
