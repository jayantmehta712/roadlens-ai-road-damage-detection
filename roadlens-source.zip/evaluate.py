import argparse
import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, ConfusionMatrixDisplay
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import config
from data import load_split, check_leakage
from predict import Predictor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default=str(config.DATASET))
    args = parser.parse_args()
    torch.set_num_threads(min(4, torch.get_num_threads()))
    predictor = Predictor()
    if predictor.model is None:
        raise SystemExit(predictor.error)
    datasets = {s: load_split(args.data, s, predictor.metadata['image_size'], predictor.classes)
                for s in ['train', 'val', 'test']}
    check_leakage(*datasets.items())
    # ImageFolder train transform is augmented, but only test is evaluated here.
    actual, predicted = [], []
    with torch.no_grad():
        for images, labels in DataLoader(datasets['test'], batch_size=16):
            predicted.extend(predictor.model(images).argmax(1).tolist())
            actual.extend(labels.tolist())
    labels = list(range(len(predictor.classes)))
    precision, recall, f1, _ = precision_recall_fscore_support(actual, predicted, labels=labels,
                                                             average='macro', zero_division=0)
    metrics = {'accuracy': accuracy_score(actual, predicted), 'precision_macro': precision,
               'recall_macro': recall, 'f1_macro': f1, 'test_images': len(actual),
               'classes': predictor.classes, 'checkpoint_epoch': predictor.metadata['epoch'],
               'report': classification_report(actual, predicted, labels=labels,
                   target_names=predictor.classes, output_dict=True, zero_division=0),
               'limitation': 'Image-level classification on this split; not localization mAP or field validation.'}
    import hashlib
    metrics['checkpoint_sha256'] = hashlib.sha256(config.MODEL_PATH.read_bytes()).hexdigest()
    config.RESULTS.mkdir(parents=True, exist_ok=True)
    (config.RESULTS / 'metrics.json').write_text(json.dumps(metrics, indent=2))
    fig, ax = plt.subplots(figsize=(8, 6))
    ConfusionMatrixDisplay.from_predictions(actual, predicted, labels=labels,
        display_labels=predictor.classes, ax=ax, cmap='Blues', colorbar=False)
    ax.set_title('Held-out test confusion matrix'); fig.tight_layout()
    fig.savefig(config.RESULTS / 'confusion_matrix.png'); plt.close(fig)
    print(json.dumps({k: v for k, v in metrics.items() if k != 'report'}, indent=2))


if __name__ == '__main__':
    main()
