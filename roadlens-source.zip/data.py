import hashlib
from pathlib import Path
from torchvision import datasets, transforms
from torchvision.transforms import InterpolationMode


def preprocessing(image_size=224, training=False):
    operations = [transforms.Resize((image_size, image_size), interpolation=InterpolationMode.BILINEAR)]
    if training:
        operations += [transforms.RandomHorizontalFlip(), transforms.RandomRotation(7),
                       transforms.ColorJitter(brightness=0.15, contrast=0.15)]
    return transforms.Compose(operations + [transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])


def load_split(root, split, image_size=224, classes=None):
    dataset = datasets.ImageFolder(Path(root) / split, transform=preprocessing(image_size, split == 'train'))
    if classes is not None and dataset.classes != classes:
        raise ValueError(f'{split} classes {dataset.classes} do not match {classes}.')
    return dataset


def check_leakage(*datasets_to_check):
    """Reject byte-identical images across splits before measuring performance."""
    seen = {}
    for split, dataset in datasets_to_check:
        for path, _ in dataset.samples:
            digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            if digest in seen and seen[digest] != split:
                raise ValueError(f'Duplicate image across {seen[digest]} and {split}: {Path(path).name}')
            seen[digest] = split
