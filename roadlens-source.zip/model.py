"""ResNet18 is a CNN: convolution, ReLU, residual blocks, pooling, linear head."""
from torch import nn
from torchvision.models import resnet18, ResNet18_Weights


def build_model(num_classes, pretrained=False, freeze_backbone=False):
    model = resnet18(weights=ResNet18_Weights.DEFAULT if pretrained else None)
    if freeze_backbone:
        for parameter in model.parameters():
            parameter.requires_grad = False
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    # Return logits for stable CrossEntropyLoss. Inference applies softmax.
    return model
